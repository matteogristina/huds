# m0rehud

m0rehud, competitive hud updated and improved by Hypnotize!

Created By: m0re

Updated by: Zimmy, Gunblade, NinjaDC, Zen

Links:

Screenshots Album: http://imgur.com/a/sxOyM

Huds.tf: http://huds.tf/forum/showthread.php?tid=248

TeamFortress.tv thread: http://www.teamfortress.tv/34115/m0re-hud

Steam Group: Soon (maybe... not)

.

.

.

F.A.Q:


1) How do i install the hud:

-Download the hud and unzip it

-Follow the "Installation Guide" file


.


2) My Fonts are looking weird/differen from the screenshots:

Go to resource/fonts and install the fonts (right click on the font file and select install)


.


3) I want to use a customization but i don't know how to do it:

Is really easy, after you install the hud (FAQ 1) select what customization you want to apply, let's take as example the "Timer With Background" Customization.
Open the "Timer With Background" folder and copy the resource folder, then go to your custom folder and paste and replace the customization files over your old hud files.
Same with any other customization!


.


4) Where i can find and enable the hud crosshairs:

Crosshairs.res file in the scripts folder! open this file and set the visible value of the crosshair you want to 1.


.

5) How can i get bigger damage numbers?

Resource > HudDamageAccount.res you need to change both "delta_item_font" and "delta_item_font_big" (default font is M0refont18Outline), you can choose between these fonts sizes:

M0refont20Outline - M0refont21Outline - M0refont22Outline - M0refont23Outline - M0refont24Outline - M0refont30Outline

.

.

IF YOU ARE GETTING ANY KIND OF PROBLEM DON'T HESITATE TO CONTACT ME HERE:

http://www.teamfortress.tv/34115/m0re-hud#top
